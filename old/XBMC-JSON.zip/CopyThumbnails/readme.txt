
A note on thumbnails & TPS-6X touchpanels:

The XBMC thumbnail images are files ending in the extension ".tbn". Crestron touchpanels cannot display these images because they 
need to end in "jpg","bmp,"png" (they display fine on iPads etc.). That is why there are two CoverArt$ string outputs, one is the original file (CoverArt$)  and one is the same file with the extension ".jpg" (CoverArt-JPG$). XBMC does not create these 'jpg' files, you'll have to do it yourself:

I wrote a small C# program that does this by copying every thumbnail, resizing it smaller and saving it in the same directory as a JPEG with the extension ".jpg". I then schedule this script to run once a day. The script is called CopyThumbnails.exe and I included it in the zip archive. It's a console application and must be run from a cmd prompt. It requires .NET 2.0. 


